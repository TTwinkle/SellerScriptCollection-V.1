INSERT INTO `items` (`name`, `label`,`limit`) VALUES
	( 'bulletsample' , 'Bullet Casing' , 1 ),
	( 'bloodsample'  , 'Blood Sample'  , 1 ),
	( 'dnaanalyzer'  , 'DNA Analyzer'  , 1 ),
	( 'ammoanalyzer' , 'Ammo Analyzer' , 1 );
