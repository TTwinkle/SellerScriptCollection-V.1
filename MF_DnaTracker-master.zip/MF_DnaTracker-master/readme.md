https://www.ModFreakz.net

Requirements
-- ESX

Installation
- 1. Import SQL file.
- 2. Place MF_DnaTracker folder into resources folder.
- 3. Config.lua to configure to your server requirements
- 3. Start MF_DnaTracker in server.cfg
- 4. Join https://discord.gg/ukgQa5K to be activated to use script (user activations happen twice a day in bulk - so it may take upto 24 hours to get this processed)