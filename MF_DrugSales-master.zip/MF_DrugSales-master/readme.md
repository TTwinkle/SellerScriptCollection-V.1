https://www.ModFreakz.net
https://discord.gg/ukgQa5K

Requirements
- ESX
- progressBars (MF fork)

Installation
- 1. Extract into resource folder.
- 2. Start MF_DrugSales in server.cfg.
- 3. Import SQL file (optional)
- 4. Check config for options you might want to change.
- 5. Join https://discord.gg/ukgQa5K to be activated to use script (user activations happen twice a day in bulk - so it may take upto 24 hours to get this processed)

Bit of info:
You can randomize the location of your sales with this mod.
The dealer will buy everything that you specify (in the config file, currently set for "meth", "weed", "cocaine") at a randomized price, sometimes high, sometimes low.
Players have a certain amount of time to get there, based off of the distance of the initial path set by the waypoint. The time is calculated by the "TargetAvgSpeed" (or something like that) var in the config file (so you can force players to race there, or allow them to drive rationally). Once the player has begun dealing with the buyer, they have a set amount of time before the police are alerted of the deal.
