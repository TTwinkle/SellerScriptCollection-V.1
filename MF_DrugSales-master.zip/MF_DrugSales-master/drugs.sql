
INSERT INTO `items` (name,label) VALUES
  ('meth','Bag of Meth'),
  ('cocaine','Bag of Cocaine'),
  ('weed','Bag of Weed');
